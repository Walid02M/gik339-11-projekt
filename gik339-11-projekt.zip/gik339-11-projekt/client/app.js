// -------------------- INSTÄLLNINGAR --------------------
const API_BASE = "http://localhost:3000";
const RESOURCE = "products";

// -------------------- ENKEL ADMIN-INLOGG --------------------
const ADMIN_PIN_CORRECT = "1234";      // Lösenord till admin inloggning
const ADMIN_STORAGE_KEY = "hm_admin";  // sparar adminläge i localStorage

// -------------------- DOM (HTML-ELEMENT) --------------------
const listMount = document.getElementById("listMount");
const refreshBtn = document.getElementById("refreshBtn");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");

// Theme
const themeToggle = document.getElementById("themeToggle");

// Kategoriknappar
const catButtons = document.querySelectorAll(".hm-cat");

// Adminpanel + formulär
const adminAddBtn = document.getElementById("adminAddBtn");
const adminPanel = document.getElementById("adminPanel");
const adminCloseBtn = document.getElementById("adminCloseBtn");

const form = document.getElementById("productForm");
const editingIdEl = document.getElementById("editingId");
const nameEl = document.getElementById("name");
const categoryEl = document.getElementById("category");
const priceEl = document.getElementById("price");
const imageUrlEl = document.getElementById("imageUrl");
const tagColorEl = document.getElementById("tagColor");
const submitBtn = document.getElementById("submitBtn");
const clearBtn = document.getElementById("clearBtn");

// Admin-modal
const adminForm = document.getElementById("adminForm");
const adminPin = document.getElementById("adminPin");
const adminLogoutBtn = document.getElementById("adminLogoutBtn");
const adminStatus = document.getElementById("adminStatus");

// Feedback-modal (meddelanden)
const feedbackModal = new bootstrap.Modal(document.getElementById("messageModal"));
const messageTitle = document.getElementById("messageTitle");
const messageBody = document.getElementById("messageBody");

// Varukorg (offcanvas)
const cartItemsEl = document.getElementById("cartItems");
const cartTotalEl = document.getElementById("cartTotal");
const cartCountEl = document.getElementById("cartCount");
const clearCartBtn = document.getElementById("clearCartBtn");

// STATE (DATA I KODEN)
let allProducts = [];
let activeCategory = "Alla";
let cart = loadCart(); // { [id]: qty }

// Admin-status
let isAdmin = localStorage.getItem(ADMIN_STORAGE_KEY) === "1";

// -------------------- START --------------------
document.addEventListener("DOMContentLoaded", async () => {
  initTheme();
  syncAdminUI();
  syncCartUI();
  await loadAndRender();
});

// Theme Dark/Light mode
function setTheme(theme) {
  document.body.setAttribute("data-theme", theme);
  localStorage.setItem("hm_theme", theme);
}
function initTheme() {
  const saved = localStorage.getItem("hm_theme") || "dark";
  setTheme(saved);
  if (themeToggle) themeToggle.checked = (saved === "dark");
}
themeToggle?.addEventListener("change", () => {
  setTheme(themeToggle.checked ? "dark" : "light");
});

// -------------------- ADMIN-INLOGG --------------------
function syncAdminUI() {
  // Admin-knappar syns bara för admin
  adminAddBtn?.classList.toggle("d-none", !isAdmin);

  // Adminpanelen ska inte vara öppen om man inte är admin
  if (!isAdmin) adminPanel?.classList.add("d-none");

  // Status-text i admin-modal
  if (adminStatus) adminStatus.textContent = `Status: ${isAdmin ? "Admin" : "Gäst"}`;

  // Logga ut-knapp syns bara för admin
  adminLogoutBtn?.classList.toggle("d-none", !isAdmin);

  // Rendera om produkterna (visa/dölj Ändra/Ta bort)
  renderFromState();
}

adminForm?.addEventListener("submit", (e) => {
  e.preventDefault();

  if ((adminPin?.value || "") === ADMIN_PIN_CORRECT) {
    isAdmin = true;
    localStorage.setItem(ADMIN_STORAGE_KEY, "1");
    if (adminPin) adminPin.value = "";
    syncAdminUI();
    showMessage("Admin", "Du är nu inloggad som admin.");
  } else {
    showMessage("Fel", "Fel admin-kod.");
  }
});

adminLogoutBtn?.addEventListener("click", () => {
  isAdmin = false;
  localStorage.removeItem(ADMIN_STORAGE_KEY);
  syncAdminUI();
  showMessage("Admin", "Du är utloggad.");
});

// -------------------- KATEGORIFILTER --------------------
catButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    activeCategory = btn.dataset.category || "Alla";

    // Om man klickar "Alla" -> rensa sök så allt syns
    if (activeCategory === "Alla" && searchInput) {
      searchInput.value = "";
    }

    renderFromState();
  });
});

// -------------------- UI-HÄNDELSER --------------------
refreshBtn?.addEventListener("click", loadAndRender);
searchInput?.addEventListener("input", renderFromState);
sortSelect?.addEventListener("change", renderFromState);

adminAddBtn?.addEventListener("click", () => {
  if (!isAdmin) return;
  adminPanel?.classList.remove("d-none");
  clearForm();
  adminPanel?.scrollIntoView({ behavior: "smooth" });
});

adminCloseBtn?.addEventListener("click", () => adminPanel?.classList.add("d-none"));
clearBtn?.addEventListener("click", clearForm);

//  HÄMTA OCH VISA (R) 
async function loadAndRender() {
  try {
    allProducts = await apiGetAll();
    renderFromState();
    syncCartUI();
  } catch (err) {
    showMessage("Fel", err?.message ?? "Kunde inte hämta produkter.");
  }
}

function renderFromState() {
  if (!listMount) return;

  const q = (searchInput?.value ?? "").trim().toLowerCase();
  let items = [...allProducts];

  // Filtrera kategori
  if (activeCategory !== "Alla") {
    items = items.filter(p => String(p.category ?? "") === activeCategory);
  }

  // Filtrera sök
  if (q) {
    items = items.filter(p =>
      String(p.name ?? "").toLowerCase().includes(q) ||
      String(p.category ?? "").toLowerCase().includes(q)
    );
  }

  // Sortera och rendera
  items = sortProducts(items, sortSelect?.value ?? "popular");
  renderProducts(items);
}

// Listan skapas dynamiskt (kravet i uppgiften)
function renderProducts(products) {
  listMount.innerHTML = "";

  if (!products.length) {
    listMount.innerHTML = `<div class="alert alert-info">Inga produkter matchar.</div>`;
    return;
  }

  const grid = document.createElement("div");
  grid.className = "row g-3";

  for (const p of products) {
    const col = document.createElement("div");
    col.className = "col-12 col-sm-6 col-xl-4";

    const card = document.createElement("div");
    card.className = "card shadow-sm hm-product";
    card.dataset.id = p.id; // ID visas inte men finns sparat
    card.style.borderLeftColor = p.tagColor || "#ff3d6a";

    const img = p.imageUrl
      ? `<img class="hm-product__img" src="${escapeAttr(p.imageUrl)}" alt="${escapeAttr(p.name)}">`
      : `<div class="hm-product__img d-flex align-items-center justify-content-center text-muted">Ingen bild</div>`;

    // Admin-knappar syns bara om man är admin
    const adminBtns = isAdmin
      ? `
        <button class="btn btn-sm btn-outline-secondary js-edit" type="button">Ändra</button>
        <button class="btn btn-sm btn-outline-danger js-delete" type="button">Ta bort</button>
      `
      : "";

    card.innerHTML = `
      <div class="card-body">
        ${img}

        <div class="mt-3 d-flex justify-content-between align-items-start gap-2">
          <div class="fw-semibold">${escapeHtml(p.name)}</div>
          <div class="fw-bold">${formatSEK(p.price)}</div>
        </div>

        <div class="text-muted small">${escapeHtml(p.category)}</div>

        <div class="d-flex justify-content-between align-items-center mt-3">
          <button class="btn btn-sm btn-hm-primary js-addcart" type="button">
            <i class="bi bi-cart-plus me-1"></i> Lägg i varukorg
          </button>

          <div class="d-flex gap-2">
            ${adminBtns}
          </div>
        </div>
      </div>
    `;

    col.appendChild(card);
    grid.appendChild(col);
  }

  listMount.appendChild(grid);
}

// Event delegation för varukorg/ändra/ta bort
listMount.addEventListener("click", async (e) => {
  const card = e.target.closest(".hm-product");
  if (!card) return;

  const id = String(card.dataset.id);

  // Lägg i varukorg
  if (e.target.closest(".js-addcart")) {
    addToCart(id, 1);
    return;
  }

  // Admin-knappar kräver admin
  if (!isAdmin) return;

  // Ta bort produkt
  if (e.target.classList.contains("js-delete")) {
    try {
      await apiDelete(id);
      showMessage("Borttagen", "Produkten togs bort.");
      await loadAndRender();
    } catch (err) {
      showMessage("Fel", err?.message ?? "Kunde inte ta bort.");
    }
  }

  // Ändra produkt (fyll formulär)
  if (e.target.classList.contains("js-edit")) {
    try {
      const product = await apiGetOne(id);
      fillFormForEdit(product);
      adminPanel?.classList.remove("d-none");
      adminPanel?.scrollIntoView({ behavior: "smooth" });
    } catch (err) {
      showMessage("Fel", err?.message ?? "Kunde inte hämta produkt för edit.");
    }
  }
});

// -------------------- FORMULÄR (C + U) --------------------
form?.addEventListener("submit", async (e) => {
  e.preventDefault();

  // Skydd: bara admin får spara
  if (!isAdmin) {
    showMessage("Åtkomst nekad", "Endast admin kan spara produkter.");
    return;
  }

  const payload = {
    name: nameEl.value.trim(),
    category: categoryEl.value,
    price: Number(priceEl.value),
    imageUrl: imageUrlEl.value.trim(),
    tagColor: tagColorEl.value
  };

  const editingId = editingIdEl.value.trim();

  try {
    // Uppdatera om ID finns, annars skapa ny
    if (editingId) {
      await apiUpdate({ id: Number(editingId), ...payload });
      showMessage("Uppdaterad", "Produkten uppdaterades.");
    } else {
      await apiCreate(payload);
      showMessage("Skapad", "Produkten skapades.");
    }

    clearForm();
    await loadAndRender();
  } catch (err) {
    showMessage("Fel", err?.message ?? "Något gick fel.");
  }
});

function fillFormForEdit(p) {
  editingIdEl.value = p.id;
  nameEl.value = p.name ?? "";
  categoryEl.value = p.category ?? "Övrigt";
  priceEl.value = p.price ?? 0;
  imageUrlEl.value = p.imageUrl ?? "";
  tagColorEl.value = p.tagColor ?? "#ff3d6a";
  submitBtn.textContent = "Uppdatera";
}

function clearForm() {
  editingIdEl.value = "";
  form.reset();
  tagColorEl.value = "#ff3d6a";
  submitBtn.textContent = "Spara";
}

// -------------------- VARUKORG --------------------
function loadCart() {
  try { return JSON.parse(localStorage.getItem("hm_cart") || "{}"); }
  catch { return {}; }
}
function saveCart() {
  localStorage.setItem("hm_cart", JSON.stringify(cart));
}
function getCartCount() {
  return Object.values(cart).reduce((sum, q) => sum + Number(q), 0);
}
function syncCartBadge() {
  const count = getCartCount();
  if (!cartCountEl) return;
  cartCountEl.textContent = String(count);
  cartCountEl.classList.toggle("d-none", count === 0);
}
function syncCartUI() {
  if (!cartItemsEl || !cartTotalEl) return;

  const entries = Object.entries(cart);
  cartItemsEl.innerHTML = "";

  // Tom varukorg
  if (entries.length === 0) {
    cartItemsEl.innerHTML = `<div class="text-muted">Varukorgen är tom.</div>`;
    cartTotalEl.textContent = formatSEK(0);
    syncCartBadge();
    return;
  }

  let total = 0;

  for (const [id, qty] of entries) {
    const p = allProducts.find(x => String(x.id) === String(id));
    if (!p) continue;

    const line = Number(p.price ?? 0) * Number(qty);
    total += line;

    const row = document.createElement("div");
    row.className = "d-flex justify-content-between align-items-start gap-2 mb-3";

    row.innerHTML = `
      <div class="flex-grow-1">
        <div class="fw-semibold">${escapeHtml(p.name)}</div>
        <div class="text-muted small">${formatSEK(p.price)} / st</div>

        <div class="d-flex align-items-center gap-2 mt-2">
          <button class="btn btn-sm btn-outline-secondary js-dec" type="button">-</button>
          <span class="fw-semibold">${Number(qty)}</span>
          <button class="btn btn-sm btn-outline-secondary js-inc" type="button">+</button>
          <button class="btn btn-sm btn-outline-danger ms-auto js-remove" type="button">Ta bort</button>
        </div>
      </div>
      <div class="fw-bold text-end">${formatSEK(line)}</div>
    `;

    // Ändra antal i varukorg
    row.querySelector(".js-dec").addEventListener("click", () => setCartQty(id, Number(qty) - 1));
    row.querySelector(".js-inc").addEventListener("click", () => setCartQty(id, Number(qty) + 1));
    row.querySelector(".js-remove").addEventListener("click", () => removeFromCart(id));

    cartItemsEl.appendChild(row);
  }

  cartTotalEl.textContent = formatSEK(total);
  syncCartBadge();
}

function addToCart(id, qty = 1) {
  cart[id] = (cart[id] || 0) + qty;
  saveCart();
  syncCartUI();
}
function removeFromCart(id) {
  delete cart[id];
  saveCart();
  syncCartUI();
}
function setCartQty(id, qty) {
  if (qty <= 0) return removeFromCart(id);
  cart[id] = qty;
  saveCart();
  syncCartUI();
}
clearCartBtn?.addEventListener("click", () => {
  cart = {};
  saveCart();
  syncCartUI();
});

// -------------------- HJÄLPFUNKTIONER --------------------
function showMessage(title, body) {
  messageTitle.textContent = title;
  messageBody.textContent = body;
  feedbackModal.show();
}
function sortProducts(items, mode) {
  const arr = [...items];
  if (mode === "priceAsc") arr.sort((a, b) => Number(a.price) - Number(b.price));
  if (mode === "priceDesc") arr.sort((a, b) => Number(b.price) - Number(a.price));
  return arr;
}
function formatSEK(value) {
  return new Intl.NumberFormat("sv-SE", { style: "currency", currency: "SEK" })
    .format(Number(value ?? 0));
}
function escapeHtml(str) {
  return String(str ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
function escapeAttr(str) {
  return escapeHtml(str).replaceAll("`", "&#096;");
}

// -------------------- API-ANROP --------------------
async function apiGetAll() {
  const res = await fetch(`${API_BASE}/${RESOURCE}`);
  if (!res.ok) throw new Error("GET /products misslyckades.");
  return res.json();
}
async function apiGetOne(id) {
  const res = await fetch(`${API_BASE}/${RESOURCE}/${id}`);
  if (!res.ok) throw new Error("GET /products/:id misslyckades.");
  return res.json();
}
async function apiCreate(payload) {
  const res = await fetch(`${API_BASE}/${RESOURCE}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error("POST /products misslyckades.");
  return res.json();
}
async function apiUpdate(payload) {
  const res = await fetch(`${API_BASE}/${RESOURCE}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error("PUT /products misslyckades.");
  return res.json();
}
async function apiDelete(id) {
  const res = await fetch(`${API_BASE}/${RESOURCE}/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("DELETE /products/:id misslyckades.");
  return res.json();
}
