// Importerar Express
const express = require("express");

// Skapar en router för /products
const router = express.Router();

// Importerar controller-funktioner för produkter
const {
  getAllProducts,   // Hämtar alla produkter (READ)
  getOneProduct,    // Hämtar en produkt via id (READ)
  createProduct,    // Skapar ny produkt (CREATE)
  updateProduct,    // Uppdaterar befintlig produkt (UPDATE)
  deleteProduct,    // Tar bort produkt (DELETE)
} = require("../controllers/productsController");

// GET /products
// Returnerar alla produkter
router.get("/", getAllProducts);

// GET /products/:id
// Returnerar en specifik produkt baserat på id
router.get("/:id", getOneProduct);

// POST /products
// Skapar en ny produkt
router.post("/", createProduct);

// PUT /products
// Uppdaterar produkt (id skickas i request body)
router.put("/", updateProduct);

// DELETE /products/:id
// Tar bort produkt baserat på id
router.delete("/:id", deleteProduct);

// Exporterar routern så den kan användas i index.js
module.exports = router;
