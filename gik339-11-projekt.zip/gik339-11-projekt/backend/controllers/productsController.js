const db = require("../db");

// Skapa tabell om den inte finns (körs när servern startar)
db.run(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL,
    imageUrl TEXT,
    tagColor TEXT
  )
`);

// GET /products  -> SELECT alla
const getAllProducts = (req, res) => {
  db.all("SELECT * FROM products ORDER BY id ASC", [], (err, rows) => {
    if (err) return res.status(500).json({ message: "DB-fel", error: err.message });
    res.json(rows);
  });
};

// GET /products/:id  -> SELECT en (id från params)
const getOneProduct = (req, res) => {
  const id = Number(req.params.id);

  db.get("SELECT * FROM products WHERE id = ?", [id], (err, row) => {
    if (err) return res.status(500).json({ message: "DB-fel", error: err.message });
    if (!row) return res.status(404).json({ message: "Produkten hittades inte" });
    res.json(row);
  });
};

// POST /products  -> INSERT (data från body)
const createProduct = (req, res) => {
  const { name, category, price, imageUrl, tagColor } = req.body || {};

  if (!name || !category) {
    return res.status(400).json({ message: "name och category krävs" });
  }

  db.run(
    `INSERT INTO products (name, category, price, imageUrl, tagColor)
     VALUES (?, ?, ?, ?, ?)`,
    [String(name), String(category), Number(price) || 0, String(imageUrl || ""), String(tagColor || "#ff3d6a")],
    function (err) {
      if (err) return res.status(500).json({ message: "DB-fel", error: err.message });

      res.status(201).json({
        id: this.lastID,
        name: String(name),
        category: String(category),
        price: Number(price) || 0,
        imageUrl: String(imageUrl || ""),
        tagColor: String(tagColor || "#ff3d6a"),
      });
    }
  );
};

// PUT /products  -> UPDATE (id från body används i WHERE)
const updateProduct = (req, res) => {
  const { id, name, category, price, imageUrl, tagColor } = req.body || {};

  if (!id) return res.status(400).json({ message: "id måste finnas i body" });

  db.run(
    `UPDATE products
     SET name = ?, category = ?, price = ?, imageUrl = ?, tagColor = ?
     WHERE id = ?`,
    [
      String(name),
      String(category),
      Number(price) || 0,
      String(imageUrl || ""),
      String(tagColor || "#ff3d6a"),
      Number(id),
    ],
    function (err) {
      if (err) return res.status(500).json({ message: "DB-fel", error: err.message });
      if (this.changes === 0) return res.status(404).json({ message: "Produkten hittades inte" });

      // Frontend behöver inte få hela objektet tillbaka, men vi skickar ett tydligt svar
      res.json({ message: "Produkten uppdaterad" });
    }
  );
};

// DELETE /products/:id  -> DELETE (id från params används i WHERE)
const deleteProduct = (req, res) => {
  const id = Number(req.params.id);

  db.run("DELETE FROM products WHERE id = ?", [id], function (err) {
    if (err) return res.status(500).json({ message: "DB-fel", error: err.message });
    if (this.changes === 0) return res.status(404).json({ message: "Produkten hittades inte" });

    res.json({ message: "Produkten borttagen" });
  });
};

module.exports = { getAllProducts, getOneProduct, createProduct, updateProduct, deleteProduct };
