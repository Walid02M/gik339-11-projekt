const db = require("./db");

const products = [
  { name: "NOCCO Raspberry Blast", category: "Energidryck", price: 29, imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8il6Mc_kcOzOUW2wCiIQPvLbbO7PgZUHeGg&s", tagColor: "#22c55e" },
  { name: "NOCCO Ramonade", category: "Energidryck", price: 29, imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJqGDWpm1wjmLbolHgKcFzWiZUeL01nFSEmw&s", tagColor: "#22c55e" },

  { name: "Whey Protein Vanilj", category: "Proteinpulver", price: 299, imageUrl: "https://www.gymgrossisten.com/dw/image/v2/BDJH_PRD/on/demandware.static/-/Sites-hsng-master-catalog/default/dw8e108baa/Nya_produktbilder/Star_Nutrition/585R_Starnutrition_Whey80_Vanilla_1kg_Feb20.jpg?sw=655&sh=655&sm=fit&sfrm=png", tagColor: "#3b82f6" },
  { name: "Whey Protein Choklad", category: "Proteinpulver", price: 299, imageUrl: "https://www.gymgrossisten.com/dw/image/v2/BDJH_PRD/on/demandware.static/-/Sites-hsng-master-catalog/default/dw96d9f895/Nya_produktbilder/Star_Nutrition/585R_Starnutrition_Whey80_Chocolate_1kg_Feb20.jpg?sw=655&sh=655&sm=fit&sfrm=png", tagColor: "#3b82f6" },
  { name: "Ultimate Vegan Protein", category: "Proteinpulver", price: 319, imageUrl: "https://www.gymgrossisten.com/dw/image/v2/BDJH_PRD/on/demandware.static/-/Sites-hsng-master-catalog/default/dw32288337/media/GG-Produktbilder/Star-Nutrition/6857-1_UltimateVeganProtein-Chocolate-1kg_0823.jpg?sw=655&sh=655&sm=fit&sfrm=png", tagColor: "#3b82f6" },
  { name: "Casein Gold Standard", category: "Proteinpulver", price: 349, imageUrl: "https://cdn.mmsports.se/resized/product-zoom/D/ON-Gold-Standard-Casein-Vanilla-1%2C8kg.jpg", tagColor: "#3b82f6" },

  { name: "Daily Multivitamin", category: "Kosttillskott", price: 129, imageUrl: "https://www.sportkost.se/pub_images/original/north_nutrition_multivitamin.jpg", tagColor: "#8b5cf6" },
  { name: "A-Z Multivitamin", category: "Kosttillskott", price: 139, imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSt5jIUgrVICLxtAk2kC1zzetaXS5my1aowAw&s", tagColor: "#8b5cf6" },
  { name: "Vitamin D3", category: "Kosttillskott", price: 99, imageUrl: "https://www.myprotein.se/images?url=https://static.thcdn.com/productimg/original/13527718-2075140071679704.jpg&format=webp&auto=avif&crop=1100,1200,smart", tagColor: "#8b5cf6" },
  { name: "Omega 3", category: "Kosttillskott", price: 149, imageUrl: "https://www.livemomentous.com/cdn/shop/files/V1_Omega-3-Bottle_2000x2000_FEB142025_CC.png?v=1740008075&width=2000", tagColor: "#8b5cf6" },
  { name: "Creatine Monohydrate", category: "Kosttillskott", price: 199, imageUrl: "https://ansupps.com/cdn/shop/files/USA-Creatine-Monohydrate-300g-Unflavored-Front.png?v=1766290352", tagColor: "#8b5cf6" },
  { name: "BCAA Vanilla Pear", category: "Kosttillskott", price: 189, imageUrl: "https://www.gymgrossisten.com/dw/image/v2/BDJH_PRD/on/demandware.static/-/Sites-hsng-master-catalog/default/dwd252ac7b/Nya_produktbilder/Star_Nutrition/6692R_Star-Nutrition_Supreme-BCAA-vanilla-pear-ice-cream_250g_Maj20.jpg?sw=655&sh=655&sm=fit&sfrm=png", tagColor: "#8b5cf6" },
  { name: "BCAA Lime Citron", category: "Kosttillskott", price: 199, imageUrl: "https://assets.icanet.se/image/upload/cs_srgb/t_product_large_2x_v1/v1668793289/qbdycuohpts5v81ff19c.webp", tagColor: "#8b5cf6" },
  { name: "Pre-Workout Tropical Fruits", category: "Kosttillskott", price: 249, imageUrl: "https://assets.icanet.se/image/upload/cs_srgb/t_product_large_2x_v1/vzcamrrxmzm5las1ndff.webp", tagColor: "#8b5cf6" },
  { name: "Pre-Workout Fresh Forest Berry", category: "Kosttillskott", price: 229, imageUrl: "https://www.gymgrossisten.com/dw/image/v2/BDJH_PRD/on/demandware.static/-/Sites-hsng-master-catalog/default/dw3956aa53/media/GG-Produktbilder/Gymgrossisten/6677R.berry.png?sw=593&sh=593&sm=fit&sfrm=png", tagColor: "#8b5cf6" },
];

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      price REAL NOT NULL,
      imageUrl TEXT,
      tagColor TEXT
    )
  `);

  db.run("DELETE FROM products"); // gör att du alltid får exakt seed-data

  const stmt = db.prepare(
    "INSERT INTO products (name, category, price, imageUrl, tagColor) VALUES (?, ?, ?, ?, ?)"
  );

  products.forEach(p => stmt.run([p.name, p.category, p.price, p.imageUrl, p.tagColor]));

  stmt.finalize(() => {
    console.log("✅ Seed klar! 15 produkter inlagda.");
    db.close();
  });
});
